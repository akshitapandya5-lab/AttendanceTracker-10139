import java.util.*;

public class AttendanceTracker {
    static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
        System.out.print("Enter number of students: ");
        int n = sc.nextInt();
        System.out.print("Enter number of days: ");
        int days = sc.nextInt();

        int[] id = new int[n];
        String[] name = new String[n];
        int[][] attendance = new int[n][days];
        HashMap<Integer, Integer> map = new HashMap<>();

        for (int i = 0; i < n; i++) {
            System.out.println("\nEnter details of student " + (i + 1));
            System.out.print("Enter ID: ");
            id[i] = sc.nextInt();
            sc.nextLine();
            System.out.print("Enter Name: ");
            name[i] = sc.nextLine();
            map.put(id[i], i);
        }

        int choice;
        do {
            System.out.println("\n===== ATTENDANCE TRACKER =====");
            System.out.println("1. Mark Attendance");
            System.out.println("2. Display Attendance");
            System.out.println("3. Search Student");
            System.out.println("4. Sort by Attendance");
            System.out.println("5. Exit");
            System.out.print("Enter choice: ");
            choice = sc.nextInt();

            switch (choice) {
                case 1:
                    System.out.print("Enter Student ID: ");
                    int sid = sc.nextInt();
                    if (map.containsKey(sid)) {
                        int index = map.get(sid);
                        System.out.print("Enter Day (1-" + days + "): ");
                        int day = sc.nextInt();
                        if (day >= 1 && day <= days) {
                            System.out.print("Enter 1 for Present, 0 for Absent: ");
                            int status = sc.nextInt();
                            if (status == 0 || status == 1) {
                                attendance[index][day - 1] = status;
                                System.out.println("Attendance Updated!");
                            } else System.out.println("Invalid status!");
                        } else System.out.println("Invalid day!");
                    } else System.out.println("Student Not Found!");
                    break;

                case 2:
                    System.out.println("\nID\tName\t\tAttendance");
                    for (int i = 0; i < n; i++) {
                        int present = 0;
                        for (int j = 0; j < days; j++) present += attendance[i][j];
                        double percentage = (present * 100.0) / days;
                        System.out.println(id[i] + "\t" + name[i] + "\t\t" + percentage + "%");
                    }
                    break;

                case 3:
                    System.out.print("Enter ID to search: ");
                    int searchId = sc.nextInt();
                    if (map.containsKey(searchId)) {
                        int index = map.get(searchId);
                        System.out.println("Student Found!");
                        System.out.println("Name: " + name[index]);
                        System.out.println("ID: " + id[index]);
                    } else System.out.println("Student Not Found!");
                    break;

                case 4:
                    int[] order = new int[n];
                    for (int i = 0; i < n; i++) order[i] = i;

                    // Bubble Sort by present-day count (same as percentage when days are equal)
                    for (int i = 0; i < n - 1; i++) {
                        for (int j = 0; j < n - i - 1; j++) {
                            int a = order[j], b = order[j + 1];
                            int p1 = 0, p2 = 0;
                            for (int k = 0; k < days; k++) {
                                p1 += attendance[a][k];
                                p2 += attendance[b][k];
                            }
                            if (p1 < p2) {
                                int temp = order[j];
                                order[j] = order[j + 1];
                                order[j + 1] = temp;
                            }
                        }
                    }

                    System.out.println("\nSorted Attendance:");
                    for (int i = 0; i < n; i++) {
                        int index = order[i], present = 0;
                        for (int j = 0; j < days; j++) present += attendance[index][j];
                        double percentage = (present * 100.0) / days;
                        System.out.println(name[index] + " - " + percentage + "%");
                    }
                    break;

                case 5:
                    System.out.println("Thank you!");
                    break;
                default:
                    System.out.println("Invalid Choice!");
            }
        } while (choice != 5);
        sc.close();
    }
}
